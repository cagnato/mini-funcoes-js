// ----------------------------------------
// 1) Funções nomeadas: operações básicas
// ----------------------------------------
function soma(a, b){ return a + b }
function subtracao(a, b){ return a - b }
function multiplicacao(a, b){ return a * b }
function divisao(a, b){
  if(b === 0) return "Erro: divisão por zero!"
  return a / b
}

// ----------------------------------------
// 2) Função que recebe outra função (callback)
// ----------------------------------------
function calcularComCallback(a, b, operacao){
  return operacao(a, b)
}

// ----------------------------------------
// Utilidades
// ----------------------------------------
const getNumbersAB = () => {
  const a = Number(document.getElementById('a').value)
  const b = Number(document.getElementById('b').value)
  return { a, b }
}

const log = (el, ...msgs) => {
  const time = new Date().toLocaleTimeString()
  el.textContent += `[${time}] ${msgs.join(" ")}\n`
  el.scrollTop = el.scrollHeight
}

// ----------------------------------------
// 3) Manipulação de arrays com arrow functions
// ----------------------------------------
const parseArray = (txt) =>
  txt.split(',')
     .map(s => s.trim())
     .filter(s => s.length > 0)
     .map(s => Number(s))
     .filter(n => !Number.isNaN(n))

const filtrarPares = arr => arr.filter(n => n % 2 === 0) // arrow
const media = arr => arr.length ? arr.reduce((acc, v) => acc + v, 0) / arr.length : NaN // arrow
const transformar = arr => arr.map(x => x*x + 1) // arrow

// ----------------------------------------
// Event listeners: Operações
// ----------------------------------------
const outOps = document.getElementById('outOps')

document.getElementById('btnSoma').addEventListener('click', function(){ // função anônima tradicional
  const {a,b} = getNumbersAB()
  log(outOps, `soma(${a}, ${b}) =`, soma(a,b))
})
document.getElementById('btnSub').addEventListener('click', () => { // arrow
  const {a,b} = getNumbersAB()
  log(outOps, `subtracao(${a}, ${b}) =`, subtracao(a,b))
})
document.getElementById('btnMul').addEventListener('click', () => {
  const {a,b} = getNumbersAB()
  log(outOps, `multiplicacao(${a}, ${b}) =`, multiplicacao(a,b))
})
document.getElementById('btnDiv').addEventListener('click', () => {
  const {a,b} = getNumbersAB()
  log(outOps, `divisao(${a}, ${b}) =`, divisao(a,b))
})
document.getElementById('btnClear').addEventListener('click', () => outOps.textContent = '')

// Callback com seletor
document.getElementById('btnCallback').addEventListener('click', () => {
  const {a,b} = getNumbersAB()
  const op = document.getElementById('operacao').value

  let func;
  switch(op){
    case 'soma': func = soma; break;
    case 'subtracao': func = subtracao; break;
    case 'multiplicacao': func = multiplicacao; break;
    case 'divisao': func = divisao; break;
    case 'custom':
      // Arrow function inline (callback custom)
      func = (x, y) => x ** y
      break;
    default:
      func = soma
  }
  const r = calcularComCallback(a, b, func)
  log(outOps, `calcularComCallback(${a}, ${b}, ${op}) =`, r)
})

// ----------------------------------------
// Event listeners: Arrays
// ----------------------------------------
const outArr = document.getElementById('outArr')
const getArr = () => parseArray(document.getElementById('arr').value)

document.getElementById('btnPares').addEventListener('click', () => {
  const arr = getArr()
  const pares = filtrarPares(arr)
  log(outArr, `Entrada: [${arr.join(', ')}]`)
  log(outArr, `Pares:   [${pares.join(', ')}]`)
})

document.getElementById('btnMedia').addEventListener('click', () => {
  const arr = getArr()
  const pares = filtrarPares(arr)
  const m = media(pares)
  log(outArr, `Média dos pares [${pares.join(', ')}] = ${Number.isNaN(m) ? '—' : m}`)
})

document.getElementById('btnTransform').addEventListener('click', () => {
  const arr = getArr()
  const tr = transformar(arr)
  log(outArr, `Transformar x → x²+1 | Entrada: [${arr.join(', ')}] | Saída: [${tr.join(', ')}]`)
})

document.getElementById('btnResetArr').addEventListener('click', () => outArr.textContent = '')
